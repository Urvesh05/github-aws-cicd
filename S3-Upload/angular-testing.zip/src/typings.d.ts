//

interface Window {
  jasmineRequire: any;
  jasmineRef: any;
}

declare module 'jasmine-core/lib/jasmine-core/jasmine.js' {
}