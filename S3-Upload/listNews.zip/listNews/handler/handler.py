import json
import psycopg2 as ps
from psycopg2.extras import RealDictCursor
import boto3
import os

# common response
response = {
    "statusCode": 200,
    "headers": {
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET,DELETE,PATCH"
    },
    "body": {
    }
}

SCHEMA_NAME = os.environ["SCHEMA_NAME"]
DATABASE_NAME = os.environ["DB_NAME"]
USER_NAME = os.environ["USER_NAME"]
PASSWORD = os.environ["PASSWORD"]
HOST_NAME =  os.environ["HOST_NAME"]
PORT =  os.environ["PORT"]
TABLE_NAME =  SCHEMA_NAME + ".raw_excel_insights"
def connect():
    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT, 
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            
            return cur

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response
def MentionsDataSource():
    cur =connect()
    try:
        sql ="""SELECT 'Medical Insights' as data_source, count(distinct insights_id)
                total_insights FROM aiip.raw_excel_insights
                UNION ALL
                SELECT 'Congress Report' as data_source, 0 as total_insights
                UNION ALL
                SELECT 'Advisory Board' as data_source, 0 as total_insights
                UNION ALL
                SELECT 'Other' as data_source, 0 as total_insights;"""
        cur.execute(sql)
        records = cur.fetchall()
        newRes = []
        for record in records:
            print("hello")
            rec = {}
            rec["data_source"] = record["data_source"]
            rec["total_insights"] = record["total_insights"]
            newRes.append(rec)

        return newRes    

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response     


def topDrugByMentions():
    cur =connect()
    try:
        sql ="""select 'Medical Insights' as data_source, ta as mentions, product as drug , count(distinct
                insights_id) as total_insights from aiip.raw_excel_insights 
                group by ta,product
                order by 3 desc;"""
        cur.execute(sql)
        records = cur.fetchall()
        newRes = []
        for record in records:
            print("hello")
            rec = {}
            rec["data_source"] = record["data_source"]
            rec["total_insights"] = record["total_insights"]
            rec["drug"]=record["drug"]
            rec["mentions"]=record["mentions"]
            newRes.append(rec)
        return newRes    

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response   

def topDrugData(event=None, context=None):
    cur = connect()
    try:
        sql ="""select 'Medical Insights' as data_source, product as drug, count(distinct
                insights_id) as total_insights from raw_excel_insights 
                group by product
                order by 3 desc"""
        cur.execute(sql)
        records = cur.fetchall()
        newRes = []
        for record in records:
            print("hello")
            rec = {}
            rec["data_source"] = record["data_source"]
            rec["drug"] = record["drug"]
            rec["total_insights"] = record["total_insights"]
            newRes.append(rec)

        return newRes    

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response     



def queryString(eventData):

    queryString = ""
    for i, ev in enumerate(eventData) :        
        qStr = "table."+ev        
        if len(eventData[ev]) > 0:
            
            join = "','".join(eventData[ev])
            
            if i != 0 : 
                qStr = f"AND {qStr} IN ('{join}')"
            else:
                qStr = f"{qStr} IN ( '{join}' )"
            
            queryString = f"{queryString} {qStr}"
    
    if queryString != "" :
        queryString = f" WHERE{queryString}"  

    return queryString


# get NewsDate
def listNews(event=None, context=None):

    print("call listNews method")

    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT,
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            cur.execute("SELECT * from "+TABLE_NAME+" LIMIT 100;")
            ###cur.execute("SELECT batch_id ,insights_id, year, ta, product,content,recorded_by,msl_region,recorded_on,medical_insight_date,source_type,created_date,file_n_name as batch_id ,insights_id, year, ta, product,content,recorded_by,msl_region,recorded_on,medical_insight_date,source_type,created_date,file_n_name  from "+TABLE_NAME+" LIMIT 10;")
            records = cur.fetchall()
            newRes = []
          
            for record in records:
                print(record)
                # print(f"AA#{record['']}")
                # print(record["batch_id"])
                timeFrame = record['created_date'].strftime("%Y") + "-" + record['created_date'].strftime("%m") + "-" + record['created_date'].strftime("%d")
                recorded_date=record['recorded_on'].strftime("%Y") + "-" + record['recorded_on'].strftime("%m") + "-" + record['recorded_on'].strftime("%d")
                medicalInsightDate=record['medical_insight_date'].strftime("%Y") + "-" + record['medical_insight_date'].strftime("%m") + "-" + record['medical_insight_date'].strftime("%d")
                rec = {}
                rec['batch_id'] = record['batch_id']
                rec['insights_id'] = record['insights_id']
                rec['year'] = record['year']
                rec['ta'] = record['ta']
                rec['product'] = record['product']
                rec['content'] = record['content']
                rec['recorded_by'] = record['recorded_by']
                rec['msl_region'] = record['msl_region']
                rec['recorded_on'] = recorded_date
                rec['medical_insight_date'] = medicalInsightDate
                rec['source_type'] = record['source_type']
                rec['created_date'] = timeFrame
                rec['file_n_name'] = record['file_n_name']
                
                newRes.append(rec)
            
            response["body"] = json.dumps(newRes)

            # print(response)

            return response

            # print(res)

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response

 

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response



# get fetchOverTime data for chart
def fetchOverTime(event=None, context=None):

    print("call fetchOverTime method")

    eventData = { "drug": ["Alks", "Vraylar","cariprazine"], "indication": ["MDD", "Schizophrenia", "Bipolar"] }
    # eventData = {}
    
    # "indication": ["Bp1", "Agitation"] 

    try :
        # call to make query
        qString = queryString(eventData)

        qString = f"SELECT DATE_TRUNC('day',created_date) AS  created_date, COUNT(Id) AS count FROM {TABLE_NAME} as table {qString} GROUP BY DATE_TRUNC('day',created_date) ORDER BY created_date ASC;"        

        print(qString)

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT,
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            # SELECT DATE_TRUNC('day',time_frame) AS  time_frame, COUNT(Id) AS count FROM key_phrases table WHERE table.drug IN ('Alks') GROUP BY DATE_TRUNC('day',time_frame) ORDER BY time_frame ASC

            cur.execute(qString)

            records = cur.fetchall()

            # print(records)
            
            newRes = {
                "time_frame" : [],
                "count": []
            }
          
            for record in records:
                                
                timeFrame = record['created_date'].strftime("%Y") + "-" + record['created_date'].strftime("%m") + "-" + record['created_date'].strftime("%d")
                                
                newRes['time_frame'].append(timeFrame)
                count = 0
                if record['count'] != "" and record['count'] > 0:
                    count = record['count']
                
                newRes['count'].append(count)                            
            
            response["body"] = json.dumps(newRes)

            # print(response)

            return response

            # print(res)

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response



    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response


# get fetchDataSource data for chart
def fetchDataSource(event=None, context=None):

    print("call fetchDataSource method")

    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT, 
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            cur.execute("SELECT data_source, count(data_source) AS count FROM " + TABLE_NAME + " AS table GROUP BY table.data_source ORDER BY table.data_source ASC;")

            records = cur.fetchall()

            newRes = []
          
            for record in records:                                                
                rec = {}
                rec['data_source'] = record['data_source']
                rec['count'] = record['count']
                            
                newRes.append(rec)
            
            response["body"] =json.dumps(newRes)

            return response

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response



    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response

## get top Drug data for chat  


# get fetchDrugData data for chart
def fetchDrugData(event=None, context=None):

    print("call fetchDrugData method")

    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT, 
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            cur.execute("SELECT DISTINCT drug, count(drug) FROM "+ TABLE_NAME +" GROUP BY drug ORDER BY drug ASC ;")

            records = cur.fetchall()

            newRes = []
          
            for record in records:                                                
                rec = {}
                rec['drug'] = record['drug']
                            
                newRes.append(rec)
            
            response["body"] = json.dumps(newRes)

            return response

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response



    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response



# get fetchDrugData data for chart
def fetchFieldData(event=None, context=None):

    print("call fetchFieldData method")

    field = event['pathParameters']['field']
    
    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT, 
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            cur.execute(f"SELECT DISTINCT {field}, count(Id) as count FROM {TABLE_NAME} GROUP BY {field} ORDER BY {field} ASC;")

            records = cur.fetchall()

            newRes = [{"name": "All", "count": 0}]
          
            for record in records:                                                
                rec = {}
                rec["name"] = record[f"{field}"]
                rec['count'] = record['count']
                            
                newRes.append(rec)
            
            response["body"] =json.dumps(newRes)

            return response

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response



    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response


# get fetchNextFieldData data for chart
def fetchNextFieldData(event=None, context=None):

    print("call fetchNextFieldData method")

    fields = ["drug","indication","dose","key_phrase","data_source"]
    
    # field = event['path']['field'];
    eventData = { 
        "search_in" : "drug",
        "search_for": "indication",
        "fields_for" : ["Alks", "Vraylar","cariprazine"]
    }

    # manage response
    response["body"]["search_in"] = eventData['search_in']
    response["body"]["search_for"] = eventData['search_for']

    newEventData = {}

    eventJson = json.loads(json.dumps(eventData))

    searchIn =  "search_in" in eventJson
    searchFor =  "search_for" in eventJson
    fieldsFor =  "fields_for" in eventJson

    print(eventData["search_for"])
    
    
    qString = ""
    qString = f"SELECT DISTINCT {eventData['search_for']} FROM {TABLE_NAME} as table group by {eventData['search_for']} order by {eventData['search_for']} ASC;"
        
    if searchIn and  eventData["search_in"] in fields :

        print("yes")

        if len(eventData['fields_for']) > 0 :
            newEventData[eventData['search_in']] = eventData['fields_for']
            # print(newEventData)
            qString = queryString(newEventData)
            # print(qString)
            qString = f"SELECT DISTINCT {eventData['search_for']} FROM {TABLE_NAME} as table {qString}  group by {eventData['search_for']} order by {eventData['search_for']} ASC;"

    print(qString)
    
    try :

        conn = ps.connect(
                    database= DATABASE_NAME,
                    user= USER_NAME,
                    password= PASSWORD,
                    host= HOST_NAME,
                    port= PORT, 
                    cursor_factory=RealDictCursor)
        cur = conn.cursor()

        if conn:
            print("connected..")

            cur.execute(qString)

            records = cur.fetchall()

            # print(records)

            newRes = []
          
            for record in records:                                                
                rec = {}
                rec["name"] = record[f"{eventData['search_for']}"]
            #     rec['count'] = record['count']
                            
                newRes.append(record[f"{eventData['search_for']}"])
            
            response["body"] = json.dumps(newRes)

            return response

        else:
            print("connection failed..")
            response["statusCode"] = 404
            return response

    except Exception as e:
        print("Some thing went wrong due to - {}".format(e))
        response["statusCode"] = 500
        response["body"] = json.dumps({"msg": "server err.."})
        return response
