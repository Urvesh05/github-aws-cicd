### Prerequisites:
* aws-cli [AWS Command Line Interface](https://aws.amazon.com/cli/)
* python3.6
* serverless

 ### Deploy stage
 serverless deploy

